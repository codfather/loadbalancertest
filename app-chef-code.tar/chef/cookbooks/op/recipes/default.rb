# --- Install packages we need ---
package 'htop'
package 'sysstat'
package 'golang-go'
