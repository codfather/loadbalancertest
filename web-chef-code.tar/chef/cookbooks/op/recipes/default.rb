# --- Install packages we need ---
package 'htop'
package 'sysstat'
package 'nginx'

# --- Deploy a configuration file ---
cookbook_file '/etc/nginx/conf.d/load-balancer.conf'
# This will copy cookbooks/op/files/default/apache2.conf (which
cookbook_file '/etc/nginx/sites-enabled/default' do
  action :delete
end

service 'nginx' do
  action :restart
end
